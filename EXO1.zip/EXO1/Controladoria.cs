﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXO1
{
    internal class Controladoria
    {
        public double totalDeImpostos { get; private set; }
        public double totalImpostosPfisica { get; private set; }
        public double totalImpostosPjuridica { get; private set; }

        List<Contribuinte> contribuintes;

        public Controladoria()
        {
        }

        public void gerenciaImpostos(Contribuinte contribuinte)
        {
            totalImpostosPfisica += contribuinte.CalcularImposto();
        }
        public double totalizaImpostos(List<Contribuinte> con)
        {
            this.contribuintes = con;
            foreach (var c in contribuintes){ 
                totalDeImpostos += c.CalcularImposto();
            }
            return totalDeImpostos;
        }
    }
}
