﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXO1
{
    internal class PessoaFisica : Contribuinte
    {

        public string cpf { get; private set; }
        public double renda { get; private set; }
        public string nome { get; private set; }
        public override double CalcularImposto()
        {
            if (this.renda <= 1400)
                return renda * 0;
            if (this.renda <= 2100)
                return renda * 0.15;
            if (this.renda <= 2800)
                return renda * 0.25;
            else
                return renda * 0.30;
        }
        public PessoaFisica(string cpf, double renda, string nome)
        {
            this.cpf = cpf;
            this.renda = renda;
            this.nome = nome;
        }

    }
}
