﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXO1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Contribuinte> contribuientes = new List<Contribuinte>();

            PessoaFisica fisica1 = new PessoaFisica("111", 1300, "alessandro");
            PessoaFisica fisica2 = new PessoaFisica("222", 1500, "marcos");
            PessoaFisica fisica3 = new PessoaFisica("333", 2200, "l");
            PessoaFisica fisica4 = new PessoaFisica("444", 3300, "pedro");
            PessoaFisica fisica5 = new PessoaFisica("444", 7000, "antonio");

            PessoaFisica j1= new PessoaFisica("555", 1300, "a");
            PessoaFisica j2 = new PessoaFisica("666", 1500, "m");
            PessoaFisica j3 = new PessoaFisica("777", 2200, "n");
            PessoaFisica j4 = new PessoaFisica("888", 3300, "p");
            PessoaFisica j5 = new PessoaFisica("999", 7000, "a");

            Controladoria controladoria = new Controladoria();

            contribuientes.Add(fisica1);
            contribuientes.Add(fisica2);
            contribuientes.Add(fisica3);
            contribuientes.Add(fisica4);
            contribuientes.Add(fisica5);
            contribuientes.Add(j1);
            contribuientes.Add(j2);
            contribuientes.Add(j3);
            contribuientes.Add(j4);
            contribuientes.Add(j5);

            //Console.WriteLine("Valor do imposto de renda: " + valor);


            //Console.WriteLine("Valor do imposto de renda: " + valorJuridica);


            foreach(var contri in contribuientes)
            {
                Console.WriteLine("Nome: " + contri.nome);
                Console.WriteLine("Renda: ");
                Console.WriteLine("Imposto devido: " + contri.CalcularImposto());
            }
        }
    }
}
