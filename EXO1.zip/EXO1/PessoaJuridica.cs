﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXO1
{
    internal class PessoaJuridica : Contribuinte
    {
        public string cnpj { get; set; }
        public string nome { get; set; }
        public double rendaBruta { get; set; }
        public override double CalcularImposto()
        {
            return this.rendaBruta * 0.10;
        }
        public PessoaJuridica(string cnpj, double rendaBruta, string nome)
        {
            this.cnpj = cnpj;
            this.nome = nome;
            this.rendaBruta = rendaBruta;
        }
    }
}
