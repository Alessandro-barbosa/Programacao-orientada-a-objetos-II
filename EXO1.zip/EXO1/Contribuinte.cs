﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXO1
{
    internal abstract class Contribuinte
    {
        public string nome { get; private set; }
        protected double rendaBruta { get; private set; }
        public abstract double CalcularImposto();

        public Contribuinte(string nome, double rendaBruta)
        {
            this.nome = nome;
            this.rendaBruta = rendaBruta;
        }
        public Contribuinte()
        {
        }
    }
}
