﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RelacionamentoEntreClasses
{
    internal class Professor
    {
        public int codigo;
        public string nome;
        public int idade;
    }
}
