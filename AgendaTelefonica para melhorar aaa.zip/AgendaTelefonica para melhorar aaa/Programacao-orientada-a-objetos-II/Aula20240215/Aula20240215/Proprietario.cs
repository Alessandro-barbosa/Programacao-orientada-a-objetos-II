﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20240215
{
    internal class Proprietario
    {    public Proprietario(string nome)
        {
            this.nome = nome;
            
        }
        String nome;        
    }
}
