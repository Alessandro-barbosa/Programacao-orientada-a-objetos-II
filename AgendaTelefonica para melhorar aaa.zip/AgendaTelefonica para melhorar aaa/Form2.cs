﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgendaTelefonica
{
    public partial class Form2 : Form
    {
        public Form2(string nome, string telefone, string trabalho, string tipo)
        {
            
            InitializeComponent();
            txtNome.Text = nome;
            txtTelefone.Text = telefone;
            txtTrabalho.Text = trabalho;
            boxTipo.Text = tipo;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            string.IsNullOrEmpty(txtNome.Text);
            var nome = txtNome.Text;
            var telefone = txtTelefone.Text;
            var trabalho = txtTrabalho.Text;
            var tipo = boxTipo.Text;
            var conteudoLista = form1.gridView.DataSource;
            
            this.Close();
        }
    }
}
