﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio2FilaAtendimento
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Queue<string> fila = new Queue<string>();
            Console.WriteLine("(1) Adicionar a fila\n" +
                "(2) Atender\n");
            do {                            
                int opcao = int.Parse(Console.ReadLine());                
                switch (opcao) {
                    case 1:
                        Console.WriteLine("Nome da pessoa a entrar na fila: ");
                        string nome = Console.ReadLine();
                        fila.Enqueue(nome);
                        break;
                    case 2:
                        if (fila.Count > 0)
                        {
                            string pessoaRemovida = fila.Dequeue();
                            Console.WriteLine($"A pessoa {pessoaRemovida} foi atendida");                            
                        }
                        else
                            Console.WriteLine("Fila vazia!");
                        break;
                    default:
                        Console.WriteLine("Nenhuma opcao escolhida!");
                        break;
                }
            }while (true);
        }
    }
}
